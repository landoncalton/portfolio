/* program 1- aloha
 *
 * The program will take a string of characters entered by the user and convert
 * them to the phonetic pronunciation of the Hawaiian word.
 *
 * Landon Calton, September 27th, 2019
 */

#include <stdio.h>

// This function will test for each of the three errors. Its argument is the character array
// passed from main. The function returns "-1" if an error occurs and the program needs to
// stop, or it returns nothing to move on to printing the syllables of the word.

int testError(char testWord[]) {
    int t;
    int k;
    int testTrue;
    for (t = 0; testWord[t] != '\0'; t++) { // This test checks if any character in the array is not
        if (testWord[t] == 'a') continue;   // one of the 12.
        else if (testWord[t] == 'e') continue;
        else if (testWord[t] == 'i') continue;
        else if (testWord[t] == 'o') continue;
        else if (testWord[t] == 'u') continue;
        else if (testWord[t] == 'p') continue;
        else if (testWord[t] == 'k') continue;
        else if (testWord[t] == 'h') continue;
        else if (testWord[t] == 'l') continue;
        else if (testWord[t] == 'm') continue;
        else if (testWord[t] == 'n') continue;
        else if (testWord[t] == 'w') continue;
        else if (testWord[t] == '\'') continue;

        printf("Character %c is not allowed.\n", testWord[t]);
        testTrue = -1;
        return testTrue;
    }
    for (t = 1; testWord[t] != '\0'; t++) { // This test checks if the first and second characters are both
        k = t - 1;                          // consonants, if the third and fourth are consonants, and so on..
        if (testWord[k] == 'a') continue;
        else if (testWord[k] == 'e') continue;
        else if (testWord[k] == 'i') continue;
        else if (testWord[k] == 'o') continue;
        else if (testWord[k] == 'u') continue;
        else if (testWord[t] == 'a') continue;
        else if (testWord[t] == 'e') continue;
        else if (testWord[t] == 'i') continue;
        else if (testWord[t] == 'o') continue;
        else if (testWord[t] == 'u') continue;

        printf("Double consonants: %c%c.\n", testWord[k], testWord[t]);
        testTrue = -1;
        return testTrue;
    }
    for (t = 0; testWord[t] != '\0'; t++); // This test checks if the last character is a consonant.
    t -= 1;
    testTrue = 0;
    if (testWord[t] == 'a') return testTrue;
    else if (testWord[t] == 'e') return testTrue;
    else if (testWord[t] == 'i') return testTrue;
    else if (testWord[t] == 'o') return testTrue;
    else if (testWord[t] == 'u') return testTrue;
    printf("Consonant %c at the end of the word.\n" , testWord[t]);
    testTrue = -1;
    return testTrue;
    }

// This function carries out the logic for converting the character string or "word" to the syllables in
// Hawaiian pronunciation. The argument is the variable holding the character array. The function returns
// nothing.

void syllWord(char spellWord[]) {
    int j;
    for (j = 0; spellWord[j] != '\0'; j++) {
        if (spellWord[j] == 'a') {                                    // Test if the current character is "a". If it
            if ((spellWord[j+1] == 'i') || (spellWord[j+1] == 'e')) { // is, follow the rules for vowels.
                printf("eye");
                j += 1;
                if ((spellWord[j + 1] == '\0') || (spellWord[j + 1] == '\''));
                else printf("-");
                continue;
            }
            else if ((spellWord[j+1] == 'o') || (spellWord[j+1] == 'u')) {
                printf("ow");
                j += 1;
                if ((spellWord[j + 1] == '\0') || (spellWord[j + 1] == '\''));
                else printf("-");
                continue;
            }
            printf("ah");
            if ((spellWord[j + 1] == '\0') || (spellWord[j + 1] == '\''));
            else printf("-");
            continue;
        }
        if (spellWord[j] == 'e') {       // Test if the current character is "e". If it is, follow the rules
            if (spellWord[j+1] == 'i') { // for vowels.
                printf("ay");
                j += 1;
                if ((spellWord[j + 1] == '\0') || (spellWord[j + 1] == '\''));
                else printf("-");
                continue;
            }
            printf("eh");
            if ((spellWord[j + 1] == '\0') || (spellWord[j + 1] == '\''));
            else printf("-");
            continue;
        }
        if (spellWord[j] == 'i') {       // Test if the current character is "i". If it is, follow the rules
            if (spellWord[j+1] == 'u') { // for vowels.
                printf("ew");
                j += 1;
                if ((spellWord[j + 1] == '\0') || (spellWord[j + 1] == '\''));
                else printf("-");
                continue;
            }
            printf("ee");
            if ((spellWord[j + 1] == '\0') || (spellWord[j + 1] == '\''));
            else printf("-");
            continue;
        }
        if (spellWord[j] == 'o') {       // Test if the current character is "o". If it is, follow the rules
            if (spellWord[j+1] == 'i') { // for vowels.
                printf("oy");
                j += 1;
                if ((spellWord[j + 1] == '\0') || (spellWord[j + 1] == '\''));
                else printf("-");
                continue;
            }
            else if (spellWord[j+1] == 'u') {
                printf("ow");
                j += 1;
                if ((spellWord[j + 1] == '\0') || (spellWord[j + 1] == '\''));
                else printf("-");
                continue;
            }
            printf("oh");
            if ((spellWord[j + 1] == '\0') || (spellWord[j + 1] == '\''));
            else printf("-");
            continue;
        }
        if (spellWord[j] == 'u') {       // Test if the current character is "a". If it is, follow the rules
            if (spellWord[j+1] == 'i') { // for vowels.
                printf("ooey");
                j += 1;
                if ((spellWord[j + 1] == '\0') || (spellWord[j + 1] == '\''));
                else printf("-");
                continue;
            }
            printf("oo");
            if ((spellWord[j + 1] == '\0') || (spellWord[j + 1] == '\''));
            else printf("-");
            continue;
        }
        if (spellWord[j] == 'w') {                       // Test if the current character is "w". If it is,
            if ((j == 0) || (spellWord[j - 1] == 'a')) { // follow the rules for the beginning of the word and
                printf("w");                             // in the middle of the word.
                continue;
            }
            if ((spellWord[j - 1] == 'o') || (spellWord[j - 1] == 'u')) {
                printf("w");
                continue;
            }
            if ((spellWord[j - 1] == 'i') || (spellWord[j - 1] == 'e')) {
                printf("v");
                continue;
            }
            printf("w");
            continue;
        }
        printf("%c" , spellWord[j]);  // This prints every consonant that comes before a vowel.
    }
}


int main() {
    char userWord[50];
    int i;

    printf("Enter a Hawaiian word:\n");
    fflush(stdout);
    scanf("%s" , userWord);  // Get input from the user.

    for (i = 0; userWord[i] != '\0'; i++) {
        if ((userWord[i] >= 'A') && (userWord[i] <= 'Z')) {  // Convert any uppercase letters in the character
            userWord[i] += 32;                               // string to lowercase.
        }
    }

    i = testError(userWord);  // Call the function to test for any errors and pass the character array. If the
    if (i == -1);             // function returns "-1" the program ends.

    else {
        syllWord(userWord);   // Call the function to print out each syllable from every character in the word.
        printf("\n");         // Print a linefeed at the end of the printed pronunciation.
    }

    return 0;
}