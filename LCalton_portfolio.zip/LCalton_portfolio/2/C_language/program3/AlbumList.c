// ECE 209 Program 3 -- December 6th, 2019
// Landon Calton
// Types and functions related to album lists
// The readAlbumFile function reads all the information from a CSV file and "remembers" for later requests
// The other functions extract information from the collection and return a list of albums

#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include "Album.h"
#include "csv.h"
#include "AlbumList.h"

AlbumNode *albumlist = NULL;            // Global variable used to store the list of albums

// Takes a standard genre string and the string passed to
// findgenre and compares them as all lowercase strings
// Returns 1 if they are equal; otherwise returns 0
int determineGen(char * genrestring, char * matchgen);

// read album collection from CSV file
// overwrites previous collection, if any
// Return value:
// 0 = error, unable to open file
// otherwise, returns the number of albums in collection
int readAlbumFile(const char *filename){
    FILE *fp = NULL;
    AlbumNode *alblist = NULL;
    Album *nextalb = NULL;
    char str[200] = {'\0'};
    int i = 0;
    int numalbs = 0;
    fp = fopen(filename , "r");
    if (fp == NULL) return 0;
    for (i = 6; i > 0; i--) {           //Read in the 6 header strings
        getCSVString(str , fp);
    }
    nextalb = newAlbumFromFile(fp);
    while (nextalb != NULL) {
        alblist = insertAlbum(nextalb , alblist);   // Inserts the next node in the album list
        numalbs += 1;                               // Keeps track of the number of albums in the list
        nextalb = newAlbumFromFile(fp);             // Gets a pointer to the next album from the file
    }
    albumlist = alblist;
    return numalbs;
}

// return a const list of all albums
// collection is the last CSV file read
const AlbumNode *allAlbums(){
    return albumlist;
}

// insert album into a list, sorted by rank
// initial list may be empty
// returns head of modified list
AlbumNode * insertAlbum(Album *a, AlbumNode *list){
    AlbumNode *lp = list, *prev = list , *newnode;
    newnode = (AlbumNode *)malloc(sizeof(AlbumNode));
    if (lp == NULL) {
        list = newnode;                             // Creates the first node of the list if the list
        newnode->album = a;                         // passed in was empty
        newnode->next = NULL;
        return list;
    }
    while (lp != NULL) {
        if (lp->album->rank < a->rank) {
            if (lp->next == NULL) {
                lp->next = newnode;                 //Case 1: Inserts an album at the end of the list
                newnode->next = NULL;
                newnode->album = a;
                break;
            }
            else {
                prev = lp;
                lp = lp->next;
            }
        }
        else if (lp == list) {                      //Case 2: Inserts an album at the front of the list
            list = newnode;
            newnode->album = a;
            newnode->next = lp;
            break;
        }
        else {                                      //Case 3: Inserts an album in the middle of the list
            prev->next = newnode;
            newnode->next = lp;
            newnode->album = a;
            break;
        }
    }
    return list;
}

// prints album list (uses printAlbum from Album.h)
void printAlbums(const AlbumNode *list){
    while(list != NULL) {
        printAlbum(list->album);
        list = list->next;
    }
}

// return album with the specified rank (if exists)
const Album * findRank(unsigned int rank){
    AlbumNode *alist = albumlist;
    while (alist != NULL){
        if (alist->album->rank == rank) return alist->album;       // Checks if current rank of album is
        alist = alist->next;                                       // equal to the rank passed in
    }                                                              // Returns null if there is no album with that
    return NULL;                                                   // rank
}

// return list of albums from given year (sorted by rank)
// must be a list that can be deleted
AlbumNode * findYear(unsigned int year){
    AlbumNode *yearalb = NULL;
    AlbumNode *alist = albumlist;
    while (alist != NULL) {
        if (alist->album->year == year){
            yearalb = insertAlbum(alist->album , yearalb);          // Compares year of current album in list
        }                                                           // to year passed in
        alist = alist->next;                                        // Returns empty list if no album year matches
    }
    return yearalb;
}

// return list of albums for given artist (sorted by rank)
// matching is case-insensitive and partial match is allowed
// must be a list that can be deleted
AlbumNode * findArtist(const char * match){
    AlbumNode *artistalb = NULL;
    AlbumNode *alist = albumlist;
    char artstr[200];
    char matchstr[200];
    int i = 0 , j = 0;
    strcpy(matchstr , match);
    while (alist != NULL) {
        strcpy(artstr, alist->album->artist);
        for (i = 0; artstr[i] != '\0'; i++) {
            artstr[i] = tolower(artstr[i]);                     // Converts the artist's name that is being matched
        }                                                       // and the current album's artist to all lowercase
        for (i = 0; match[i] != '\0'; i++) {                    // before comparing
            matchstr[i] = tolower(matchstr[i]);
        }
        for (i = 0; artstr[i] != '\0'; i++) {
            while (artstr[i] == matchstr[j]) {
                if (artstr[i + 1] == '\0' || matchstr[j + 1] == '\0') {
                    artistalb = insertAlbum(alist->album, artistalb);
                    break;
                }
                i++;
                j++;
            }
            j = 0;
        }
        alist = alist->next;
    }
    return artistalb;
}

// return list of albums of a given genre (sorted by rank)
// case-insensitive search, but must match complete word, no partial match
// (e.g. "r" does NOT match "Rock", "folk" does match "Folk & Country")
// must be a list that can be deleted
AlbumNode * findGenre(const char * genreWord){
    AlbumNode *genrealb = NULL;
    AlbumNode *alist = albumlist;
    int gennum = 0;
    char matchstr[15];
    char genstr[15];
    int i = 0;
    strcpy(matchstr , genreWord);
    for (i = 0; matchstr[i] != '\0'; i++){
        matchstr[i] = tolower(matchstr[i]);
    }
    strcpy(genstr , BLUES_STR);
    if (determineGen(genstr , matchstr)){                   // Takes the standard genre string and genre string to be
        gennum += BLUES;                                    // matched and sets the genre number equal to that standard
    }                                                       // genre's code if the strings are equal
    strcpy(genstr , CLASSICAL_STR);
    if (determineGen(genstr , matchstr)){
        gennum += CLASSICAL;
    }
    strcpy(genstr , ELECTRONIC_STR);
    if (determineGen(genstr , matchstr)){
        gennum += ELECTRONIC;
    }
    strcpy(genstr , FOLK_COUNTRY_STR);
    if (determineGen(genstr , matchstr)){
        gennum += FOLK_COUNTRY;
    }
    strcpy(genstr , FUNK_SOUL_STR);
    if (determineGen(genstr , matchstr)){
        gennum += FUNK_SOUL;
    }
    strcpy(genstr , HIP_HOP_STR);
    if (determineGen(genstr , matchstr)){
        gennum += HIP_HOP;
    }
    strcpy(genstr , JAZZ_STR);
    if (determineGen(genstr , matchstr)){
        gennum += JAZZ;
    }
    strcpy(genstr , LATIN_STR);
    if (determineGen(genstr , matchstr)){
        gennum += LATIN;
    }
    strcpy(genstr , POP_STR);
    if (determineGen(genstr , matchstr)){
        gennum += POP;
    }
    strcpy(genstr , REGGAE_STR);
    if (determineGen(genstr , matchstr)){
        gennum += REGGAE;
    }
    strcpy(genstr , ROCK_STR);
    if (determineGen(genstr , matchstr)){
        gennum += ROCK;
    }
    strcpy(genstr , STAGE_SCREEN_STR);
    if (determineGen(genstr , matchstr)){
        gennum += STAGE_SCREEN;
    }
    if (gennum == 0) return NULL;                                   // Returns an empty list if the genre string passed
                                                                    // in is not standard/ invalid
    while (alist != NULL){
        if ((alist->album->genre & gennum) == gennum){
            genrealb = insertAlbum(alist->album , genrealb);        // Bitwise-and used to check if a multiple genre
        }                                                           // code or any genre code contains the specified
        alist = alist->next;                                        // genre passed in
    }
    return genrealb;
}

int determineGen(char * genrestring, char * matchgen){
    int i = 0 , j = 0;
    for (i = 0; genrestring[i] != '\0'; i++){
        if (isalpha(genrestring[i])){
            genrestring[i] = tolower(genrestring[i]);               // Converts the standard genre string to all
        }                                                           // lowercase
    }
    if (strcmp(genrestring , matchgen) == 0){                       // Checks if the two strings are exact match
        return 1;
    }
    else for (i = 0; genrestring[i] != '\0'; i++) {
            while (genrestring[i] == matchgen[j]){                              // Checks if the genre string passed to
                if (matchgen[j + 1] == '\0' && genrestring[i + 1] == '\0'){     // findGenre is a word that matches the
                    return 1;                                                   // LAST word of the standard genre
                }
                if (matchgen[j + 1] == '\0' && genrestring[i + 1] == ' '){      // Checks if the genre string passed to
                    return 1;                                                   // findGenre is a word that matches the
                }                                                               // FIRST word of the standard genre
                i++;
                j++;
            }
            j = 0;
        }
    return 0;
}