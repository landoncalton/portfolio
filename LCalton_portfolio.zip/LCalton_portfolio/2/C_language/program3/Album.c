// ECE 209 Program 3 -- December 6th, 2019
// Landon Calton
// This file holds the functions that directly manipulate the info in the album structs
// The functions for converting genre codes to strings and vice versa, adding a new album
// struct from the file, and printing the information of one album to the console are below

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "csv.h"
#include "Album.h"

// bit fields for genre
// an album's genre is a bitmap with one or more bits set
#define BLUES           ((unsigned int) 1)       // 0x001
#define CLASSICAL       ((unsigned int) 2)       // 0x002
#define ELECTRONIC      ((unsigned int) 4)       // 0x004
#define FOLK_COUNTRY    ((unsigned int) 8)       // 0x008
#define FUNK_SOUL       ((unsigned int) 16)      // 0x010
#define HIP_HOP         ((unsigned int) 32)      // 0x020
#define JAZZ            ((unsigned int) 64)      // 0x040
#define LATIN           ((unsigned int) 128)     // 0x080
#define POP             ((unsigned int) 256)     // 0x100
#define REGGAE          ((unsigned int) 512)     // 0x200
#define ROCK            ((unsigned int) 1024)    // 0x400
#define STAGE_SCREEN    ((unsigned int) 2048)    // 0x800
#define GENRE_MAX       STAGE_SCREEN    // value of largest genre code

// standardized strings for genre
// CSV file is guaranteed to contain these strings
#define BLUES_STR           "Blues"
#define CLASSICAL_STR       "Classical"
#define ELECTRONIC_STR      "Electronic"
#define FOLK_COUNTRY_STR    "Folk & Country"
#define FUNK_SOUL_STR       "Funk / Soul"
#define HIP_HOP_STR         "Hip Hop"
#define JAZZ_STR            "Jazz"
#define LATIN_STR           "Latin"
#define POP_STR             "Pop"
#define REGGAE_STR          "Reggae"
#define ROCK_STR            "Rock"
#define STAGE_SCREEN_STR    "Stage & Screen"

#define GENRE_STR_MAX   14   // strlen of longest genre string

// given string, return encoded genre
// if error, returns 0
unsigned int stringToGenre(const char *str){
    char string[GENRE_STR_MAX + 1];
    int i = 0 , j = 0;
    unsigned int genreNum = 0;

    while (str[i] != '\0') {
        if (str[i] != ',' || str[i + 1] == '\0') {              // Partially copies string passed in to local variable
            string[j] = str[i];                                 // Allows each genre in the string to be separately
            i++;                                                // compared
            j++;
        }
        if (str[i] == ',' || str[i] == '\0') {
            string[j] = '\0';
            if (strcmp(string, BLUES_STR) == 0) {               // Each standard genre string is compared to the
                genreNum += BLUES;                              // string passed in
                if (str[i] == '\0') break;                      // If they are equal the corresponding genre code is
                i += 2;                                         // added to genreNum
                j = 0;
                strcpy(string, "");
                continue;
            }
            if (strcmp(string, CLASSICAL_STR) == 0) {
                genreNum += CLASSICAL;
                if (str[i] == '\0') break;
                i += 2;
                j = 0;
                strcpy(string, "");
                continue;
            }
            if (strcmp(string, ELECTRONIC_STR) == 0) {
                genreNum += ELECTRONIC;
                if (str[i] == '\0') break;
                i += 2;
                j = 0;
                strcpy(string, "");
                continue;
            }
            if (strcmp(string, FOLK_COUNTRY_STR) == 0) {
                genreNum += FOLK_COUNTRY;
                if (str[i] == '\0') break;
                i += 2;
                j = 0;
                strcpy(string, "");
                continue;
            }
            if (strcmp(string, FUNK_SOUL_STR) == 0) {
                genreNum += FUNK_SOUL;
                if (str[i] == '\0') break;
                i += 2;
                j = 0;
                strcpy(string, "");
                continue;
            }
            if (strcmp(string, HIP_HOP_STR) == 0) {
                genreNum += HIP_HOP;
                if (str[i] == '\0') break;
                i += 2;
                j = 0;
                strcpy(string, "");
                continue;
            }
            if (strcmp(string, JAZZ_STR) == 0) {
                genreNum += JAZZ;
                if (str[i] == '\0') break;
                i += 2;
                j = 0;
                strcpy(string, "");
                continue;
            }
            if (strcmp(string, LATIN_STR) == 0) {
                genreNum += LATIN;
                if (str[i] == '\0') break;
                i += 2;
                j = 0;
                strcpy(string, "");
                continue;
            }
            if (strcmp(string, POP_STR) == 0) {
                genreNum += POP;
                if (str[i] == '\0') break;
                i += 2;
                j = 0;
                strcpy(string, "");
                continue;
            }
            if (strcmp(string, REGGAE_STR) == 0) {
                genreNum += REGGAE;
                if (str[i] == '\0') break;
                i += 2;
                j = 0;
                strcpy(string, "");
                continue;
            }
            if (strcmp(string, ROCK_STR) == 0) {
                genreNum += ROCK;
                if (str[i] == '\0') break;
                i += 2;
                j = 0;
                strcpy(string, "");
                continue;
            }
            if (strcmp(string, STAGE_SCREEN_STR) == 0) {
                genreNum += STAGE_SCREEN;
                if (str[i] == '\0') break;
                i += 2;
                j = 0;
                strcpy(string, "");
                continue;
            }
            if (strcmp(string, CLASSICAL_STR) == 0) {
                genreNum += CLASSICAL;
                if (str[i] == '\0') break;
                i += 2;
                j = 0;
                strcpy(string, "");
                continue;
            }
            return 0;                        // Returns zero if the string passed in does not match a standard genre
        }
    }
    return genreNum;
}
// given encoded genre, write string to str (caller must make sure there's enough space)
// if no error, returns ptr to string; if error, returns NULL (str may have been changed)
// resulting string must list genres in alphabetical order, separated by comma and a single space
char * genreToString(unsigned int g, char *str){
        unsigned int genre = g;
        if (genre == 0) return NULL;
        if ((genre & BLUES) == BLUES) {                     // Takes each genre number passed in and uses bitwise-and
            strcat(str , BLUES_STR);                        // with a standard genre code to check if that single
            genre -= BLUES;                                 // genre number is part of the total genre number
            if (genre != 0) {                               // Removes single genre number from total number if true
                strcat(str, ", ");                          // Adds the comma and space between genres in the string
            }                                               // if the genre number passed in is not zero
        }
        if ((genre & CLASSICAL) == CLASSICAL) {
            strcat(str , CLASSICAL_STR);
            genre -= CLASSICAL;
            if (genre != 0) {
                strcat(str, ", ");
            }
        }
        if ((genre & ELECTRONIC) == ELECTRONIC) {
            strcat(str , ELECTRONIC_STR);
            genre -= ELECTRONIC;
            if (genre != 0) {
                strcat(str, ", ");
            }
        }
        if ((genre & FOLK_COUNTRY) == FOLK_COUNTRY) {
            strcat(str , FOLK_COUNTRY_STR);
            genre -= FOLK_COUNTRY;
            if (genre != 0) {
                strcat(str, ", ");
            }
        }
        if ((genre & FUNK_SOUL) == FUNK_SOUL) {
            strcat(str , FUNK_SOUL_STR);
            genre -= FUNK_SOUL;
            if (genre != 0) {
                strcat(str, ", ");
            }
        }
        if ((genre & HIP_HOP) == HIP_HOP) {
            strcat(str , HIP_HOP_STR);
            genre -= HIP_HOP;
            if (genre != 0) {
                strcat(str, ", ");
            }
        }
        if ((genre & JAZZ) == JAZZ) {
            strcat(str , JAZZ_STR);
            genre -= JAZZ;
            if (genre != 0) {
                strcat(str, ", ");
            }
        }
        if ((genre & LATIN) == LATIN) {
            strcat(str , LATIN_STR);
            genre -= LATIN;
            if (genre != 0) {
                strcat(str, ", ");
            }
        }
        if ((genre & POP) == POP) {
            strcat(str , POP_STR);
            genre -= POP;
            if (genre != 0) {
                strcat(str, ", ");
            }
        }
        if ((genre & REGGAE) == REGGAE) {
            strcat(str , REGGAE_STR);
            genre -= REGGAE;
            if (genre != 0) {
                strcat(str, ", ");
            }
        }
        if ((genre & ROCK) == ROCK) {
            strcat(str , ROCK_STR);
            genre -= ROCK;
            if (genre != 0) {
                strcat(str, ", ");
            }
        }
        if ((genre & STAGE_SCREEN) == STAGE_SCREEN) {
            strcat(str , STAGE_SCREEN_STR);
            genre -= STAGE_SCREEN;
            if (genre != 0) {
                strcat(str, ", ");
            }
        }
        if (genre != 0) return NULL;               // Returns NULL pointer if the genre number passed in was invalid
        return str;
}

// read the next album from the CSV file, create a new struct album containing the information
// Return value:
// if successful, pointer to allocated and initialized struct
// otherwise, NULL
Album * newAlbumFromFile(FILE* fp){
    Album * newAlbum;
    newAlbum = (Album *)malloc(sizeof(Album));
    int num = 0;
    unsigned int gennum = 0;
    char str[200];
    int status = 1;
    status = getCSVInt(&num , fp);                      // Uses csv functions to read each csv field in order, storing
    if (status != 1) return NULL;                       // to the correct field of the new album struct
    newAlbum->rank = num;                               // If the field is invalid returns a NULL pointer
    status = getCSVInt(&num , fp);
    if (status != 1) return NULL;
    newAlbum->year = num;
    status = getCSVString(str , fp);
    if (status != 1) return NULL;
    strcpy(newAlbum->title , str);
    status = getCSVString(str , fp);
    if (status != 1) return NULL;
    strcpy(newAlbum->artist , str);
    status = getCSVString(str , fp);
    if (status != 1) return NULL;
    gennum = stringToGenre(str);
    newAlbum->genre = gennum;
    getCSVString(str , fp);

    return newAlbum;
}

// prints album information to standard output
void printAlbum(const Album* a){
    char genreStr[50] = {'\0'};
    char *printGenre = NULL;
    if (a != NULL) {
        printGenre = genreToString(a->genre , genreStr);
        if (printGenre != NULL) {                               // If the genre to print is not one of the standard
            printf("#%d: %s\n", a->rank, a->title);             // genres, nothing is printed
            printf(">> %s (%d) :: %s\n", a->artist, a->year, printGenre);
        }
    }
}


