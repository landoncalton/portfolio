#include <stdio.h>
#include <string.h>
#include "csv.h"
#include "Album.h"
#include "AlbumList.h"

int main() {
    FILE * fp = fopen("sample_int.csv" , "r");
    int status = 1;
    int num = 0;
    
    while(status) {
        status = getCSVInt(&num, fp);
        printf("%d" , num);
    }
    printf("\n");

    FILE * filep = fopen("sample_str.csv" , "r");
    status  = 1;
    char str[100];


    AlbumNode *genrelist = NULL;
    readAlbumFile("short.csv");
    genrelist = findGenre("funk / Soul");
    if (genrelist != NULL){
        printAlbums(genrelist);
    }
    else printf("Genre not found.\n");
    
    Album testAlb;
    testAlb.genre = FUNK_SOUL;
    testAlb.year = 1999;
    strcpy(testAlb.artist , "Lil Wayne");
    strcpy(testAlb.title , "6-Foot 7-Foot");
    testAlb.rank = 47;
    printAlbum(&testAlb);
    
    
    // Tests function in Album.c //
    getCSVString(str , filep);
    stringToGenre(str);
    
    while (status) {
        status = getCSVString(str , filep);
        printf("%s" , str);
    }
    printf("\n");

    return 0;
}

