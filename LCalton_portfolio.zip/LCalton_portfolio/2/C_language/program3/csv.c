// ECE 209 Program 3 -- December 6th, 2019
// Landon Calton
// These functions read and extract the information fields of the CSV files

#include <stdio.h>

// getCSVString: Extract the next field from a CSV file, as a string
// Field is stored into str -- caller must be sure that str is large enough.
// Return values:
// 0 = no field extracted (could be error, or could be EOF)
// 1 = success, field extracted
// if 0 returned str could be changed, but caller should ignore
// File pointer fp must be moved to the beginning of the next field to be read

int getCSVString(char * str, FILE* fp){
    FILE * filep = fp;
    char getchar;
    int status = 1;
    int dq = 0;
    int i = 0;
    while (status == 1) {
        status = fscanf(filep , "%1c" , &getchar);              // Scan the file character-by-character for each field
        if (status == EOF) return 0;
        if (getchar == '\"') {
            dq = 1;
            status = fscanf(filep, "%1c", &getchar);
            if (getchar == ',' || getchar == '\n') {            // This code executes after a " mark is read
                status = 0;                                     // Scan for each string field ends if the current
                continue;                                       // character is a comma or linefeed
            }
            else {
                str[i] = getchar;                               // Add each character from string field to string
                i++;                                            // variable to be returned
                continue;
            }
        }
        if (getchar == ',' || getchar == '\n') {                // Stops scanning if the current character is a comma
            if (dq == 0) break;                                 // or linefeed; dq variable takes care of case when
        }                                                       // there is a comma/linefeed inside a " mark that is
        str[i] = getchar;                                       // stored
        i++;
    }
    str[i] = '\0';
    return 1;
}

// getCSVInt: Extract the next field from a CSV file as a decimal integer
// Caller provides the address where integer should be stored
// Return value:
// 0 = no integer extracted (could be error, or could be EOF)
// 1 = success, field extracted
// if 0 returned, *num could be changed, but caller should ignore
// File pointer fp must be moved to the beginning of the next field to be read

int getCSVInt(int * num, FILE* fp){
    FILE * filep = fp;
    int getnum;
    int status;
    char c;
    status = fscanf(filep , "%d" , &getnum);
    if (status == EOF) return 0;
    *num = getnum;
    fscanf(filep , "%c" , &c);

    return 1;
}