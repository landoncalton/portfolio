// Program 2
// Landon Calton
// November 1st, 2019
// The file contains the seven functions that will be called from the
// user-interface and used to preform operations on the sound files.
// Operations include copying, echoing, filtering, mixing, and reading
// the sound files. Each function returns an error for incorrect
// file format, an error for not being able to open a file, or 0 if
// the function completes with no errors.

#include "audio.h"
#include <string.h>

// headerInfo is an array of 5 integers
// 0: number of channels
// 1: sample rate (samples / sec)
// 2: sample block size (bytes) -- all channels
// 3: sample size (bits) -- per channel
// 4: number of samples

// Creates a new file that is an exact copy of the original.
// Arguments are input and output file names.
// Returns success or errors for incorrect format or file.
int copyWAV(const char* infileName, const char* outfileName) {
    int info[5];
    int numSamples = 0;
    int sampBytes = 0;
    int i = 0;
    char dataStore[sampBytes];
    FILE* fileout = NULL;
    FILE* filein = NULL;
    filein = fopen(infileName , "rb");
    if (filein == NULL) return 1;
    fclose(filein);
    filein = openWAVRead(infileName , info);
    if (filein == NULL) return 3;
    fileout = fopen(outfileName , "wb");
    if (fileout == NULL) return 2;
    fclose(fileout);
    fileout = openWAVWrite(outfileName , info);
    if (fileout == NULL) return 3;

    sampBytes = info[2];
    while (numSamples < info[4]) {
        for (i = 0; i < sampBytes; i++) {
            fread(&dataStore[i] , sizeof(unsigned char) , 1 , filein);
        }
        for (i = 0; i < sampBytes; i++) {
            fwrite(&dataStore[i] , sizeof(unsigned char) , 1 , fileout);
        }
        numSamples++;
    }

    fclose (filein);
    fclose (fileout);
    return 0;
}

// Adds an echo of the original file into the output file.
// Each output sample = (input sample + delayed input sample) / 2.
// The # of samples in the output file is the same as the original file.
// Arguments are the input and output file names and delay value.
// Returns success or errors for incorrect format or file.
int echoWAV(const char* infileName, int delay, const char* outfileName) {
    return 1;
}

// Applies a digital filter to the input file.
// Each output sample = average of previous N input samples.
// The # of samples in the output file is the same as the original file.
// Arguments are the input file name, output file name, and length.
// Returns success or errors for incorrect format or file.
int filterWAV(const char* infileName, int length, const char* outfileName) {
    return 1;
}

// Creates a weighted mixture of two input files.
// Each output sample = (input sample 1 * perCent1 + input sample 2 * perCent2) / 100.
// The # of samples in the output file is the same as the longest input file.
// Arguments are the input file names, percentages, and output file name.
// Returns 0 for success and errors for incorrect format or file.
int mixWAV(const char* infileName1, int perCent1, const char* infileName2, int perCent2, const char* outfileName) {
    int info1[5];
    int info2[5];
    int info3[5];
    int i = 0;
    int sampBits = 0;
    int sampBytes = 0;
    int numSamples = 0;
    unsigned char dataStore1 = 0;
    unsigned char dataStore2 = 0;
    unsigned char dataStore3 = 0;
    FILE* filein1 = NULL;
    FILE* filein2 = NULL;
    FILE* fileout = NULL;
    filein1 = openWAVRead(infileName1 , info1);
    if (filein1 == NULL) return 1;
    filein2 = openWAVRead(infileName2 , info2);
    if (filein2 == NULL) return 1;
    if (info1[0] != info2[0] || info1[1] != info2[1] || info1[3] != info2[3]) {
        return 3;
    }
    if (info1[4] > info2[4]) {
        for (i = 0; i < 5; i++) info3[i] = info1[i];
    }
    else for (i = 0; i < 5; i++) info3[i] = info2[i];
    fileout = openWAVWrite(outfileName , info3);
    if (fileout == NULL) return 1;

    //() - (1 << sampBits + 1)

    sampBits = info3[3];
    sampBytes = (sampBits / 8);  // Get the number of bytes per sample per channel.
    while (numSamples < info3[4]) {
        fread(&dataStore1 , sizeof(unsigned char) , sampBytes , filein1);
        if ((dataStore1 >> (sampBits - 1)) == 1) {
            dataStore1 = dataStore1 - (1 << (sampBits + 1));
        }
        fread(&dataStore2 , sizeof(unsigned char) , sampBytes , filein2);
        if ((dataStore2 >> ((sampBytes * 8) - 1)) == 1) {
            dataStore2 = dataStore2 - (1 << ((sampBytes * 8) + 1));
        }
        for (i = 0; i < sampBytes; i++) {
            dataStore3 = ((dataStore1 * perCent1) + (dataStore2 * perCent2)) / 100;
        }
        for (i = 0; i < sampBytes; i++) {
            fwrite(&dataStore3 , sizeof(unsigned char) , sampBytes , fileout);
        }
        numSamples++;
    }


    return 0;
}

// Open and read input file, which should be in WAV format.
// Extract information and print to console.
// Return values:
// 0 = success
// 1 = could not open input file
// 3 = error in input file format
int readWAV(const char* infileName) {
    char fourInfo[5] = "NULL";
    unsigned char binfo;
    int i;
    int numItem = 0;
    int sampBytes = 0;
    FILE* fileIn = NULL;
    fileIn = fopen(infileName, "rb");
    if (fileIn == NULL) return 1;
    fread(fourInfo , sizeof(unsigned char) , 4 , fileIn);
    if (strcmp(fourInfo , "RIFF") != 0) {
        printf("RIFF not found.\n");
        return 3;
    }
    else printf("RIFF confirmed.\n");
    fread(fourInfo , sizeof(unsigned char) , 4 , fileIn);
    fread(fourInfo , sizeof(unsigned char) , 4 , fileIn);
    if (strcmp(fourInfo , "WAVE") != 0) {
        printf("WAVE not found.\n");
        return 3;
    }
    else printf("WAVE confirmed.\n");
    fread(fourInfo , sizeof(unsigned char) , 4 , fileIn);
    if (strcmp(fourInfo, "fmt ") != 0) {
        printf("fmt block not found.\n");
        return 3;
    }
    printf("----- fmt block -----\n");
    for (i = 0; i < 4; i++) {
        fread(&binfo , sizeof(unsigned char), 1 , fileIn);
        numItem = numItem + (binfo << (8 * i));
    }
    if (numItem == 16) {
        printf("fmt size: %d\n", numItem);
    }
    else {
        printf("fmt size: %d\n", numItem);
        sampBytes += 1;
    }
    numItem = 0;
    for (i = 0; i < 2; i++) {
        fread(&binfo , sizeof(unsigned char), 1 , fileIn);
        numItem = numItem + (binfo << (8 * i));
    }
    if (numItem == 1) {
        printf("fmt code: %d\n", numItem);
    }
    else {
        printf("fmt code: %d\n", numItem);
        sampBytes += 1;
    }
    if (sampBytes > 0) {
        printf("Unsupported format.\n");
        return 3;
    }
    numItem = 0;
    for (i = 0; i < 2; i++) {
        fread(&binfo , sizeof(unsigned char), 1 , fileIn);
        numItem = numItem + (binfo << (8 * i));
    }
    printf("Channels: %d\n" , numItem);
    numItem = 0;
    for (i = 0; i < 4; i++) {
        fread(&binfo , sizeof(unsigned char), 1 , fileIn);
        numItem = numItem + (binfo << (8 * i));
    }
    printf("Sample rate (samples/sec): %d\n" , numItem);
    numItem = 0;
    for (i = 0; i < 4; i++) {
        fread(&binfo , sizeof(unsigned char), 1 , fileIn);
        numItem = numItem + (binfo << (8 * i));
    }
    printf("Data rate (bytes/sec): %d\n" , numItem);
    numItem = 0;
    for (i = 0; i < 2; i++) {
        fread(&binfo , sizeof(unsigned char), 1 , fileIn);
        numItem = numItem + (binfo << (8 * i));
    }
    sampBytes = numItem;
    printf("Bytes per sample (all channels): %d\n" , numItem);
    numItem = 0;
    for (i = 0; i < 2; i++) {
        fread(&binfo , sizeof(unsigned char), 1 , fileIn);
        numItem = numItem + (binfo << (8 * i));
    }
    printf("Bits per sample (one channel): %d\n" , numItem);
    fread(fourInfo , sizeof(unsigned char) , 4 , fileIn);
    if (strcmp(fourInfo, "data") != 0) {
        printf("data block not found.\n");
        return 3;
    }
    printf("----- data block -----\n");
    numItem = 0;
    for (i = 0; i < 4; i++) {
        fread(&binfo , sizeof(unsigned char), 1 , fileIn);
        numItem = numItem + (binfo << (8 * i));
    }
    numItem = (numItem / sampBytes);
    printf("Samples: %d\n" , numItem);

    fclose(fileIn);

    return 0;
}

// Open WAV file for reading, then read header and extract information.
// Arguments are the file name and an array to store important header information.
// Return values:
// If success, return input stream.
// If could not open, or if some file format error, return 0.
FILE* openWAVRead(const char* name, int * info) {
    char alsojunk[5] = "";
    unsigned char junk;
    int i;
    int item = 0;
    FILE* file1 = NULL;
    file1 = fopen(name, "rb");
    if (file1 == NULL) return 0;
    fread(alsojunk , sizeof(unsigned char) , 4 , file1);
    if (strcmp(alsojunk , "RIFF") != 0) {
        return 0;
    }
    fread(&junk , sizeof(unsigned char) , 4 , file1);
    fread(alsojunk , sizeof(unsigned char) , 4 , file1);
    if (strcmp(alsojunk , "WAVE") != 0) {
        return 0;
    }
    fread(alsojunk , sizeof(unsigned char) , 4 , file1);
    if (strcmp(alsojunk , "fmt ") != 0) {
        return 0;
    }
    for (i = 0; i < 4; i++) {
        fread(&junk , sizeof(unsigned char), 1 , file1);
        item = item + (junk << (8 * i));
    }
    if (item != 16) return 0;
    item = 0;
    for (i = 0; i < 2; i++) {
        fread(&junk , sizeof(unsigned char), 1 , file1);
        item = item + (junk << (8 * i));
    }
    if (item != 1) return 0;

    *info = 0;
    for (i = 0; i < 2; i++) {
        fread(&junk, sizeof(unsigned char), 1, file1);
        *info = *info + (junk << (8 * i));
    }
    info++;
    *info = 0;
    for (i = 0; i < 4; i++) {
        fread(&junk , sizeof(unsigned char), 1 , file1);
        *info = *info + (junk << (8 * i));
    }
    fread(&junk , sizeof(unsigned char) , 4 , file1);
    info++;
    *info = 0;
    for (i = 0; i < 2; i++) {
        fread(&junk, sizeof(unsigned char), 1, file1);
        *info = *info + (junk << (8 * i));
    }
    item = *info;
    info++;
    *info = 0;
    for (i = 0; i < 2; i++) {
        fread(&junk, sizeof(unsigned char), 1, file1);
        *info = *info + (junk << (8 * i));
    }
    info++;
    *info = 0;
    fread(alsojunk , sizeof(unsigned char) , 4 , file1);
    if (strcmp(alsojunk , "data") != 0) {
        return 0;
    }
    for (i = 0; i < 4; i++) {
        fread(&junk , sizeof(unsigned char), 1 , file1);
        *info = *info + (junk << (8 * i));
    }
    *info = *info / item;


    return file1;
}

// Open WAV file for writing, then write header using provided info.
// Arguments are the file name and an array to store important header information.
// Return values:
// If success, return output stream.
// If could not open, return 0.
FILE* openWAVWrite(const char* name, const int * info) {
    char itemTag[5];
    unsigned char junk;
    int i;
    FILE* file1 = NULL;
    file1 = fopen(name, "wb");
    if (file1 == NULL) return 0;
    fwrite("RIFF" , sizeof(unsigned char) , 4 , file1);
    for (i = 0; i < 4; i++) {
        junk = ((info[4] * info[0] * (info[3] / 8)) + 36) >> (8 * i);
        fwrite(&junk, sizeof(unsigned char), 1 , file1);
    }
    strcpy(itemTag , "WAVE");
    fwrite(itemTag , sizeof(unsigned char) , 4 , file1);
    strcpy(itemTag ,"fmt ");
    fwrite(itemTag , sizeof(unsigned char) , 4 , file1);
    junk = 16;
    fwrite(&junk, sizeof(unsigned char), 1 , file1);
    junk = 0;
    fwrite(&junk, sizeof(unsigned char), 1 , file1);
    fwrite(&junk, sizeof(unsigned char), 1 , file1);
    fwrite(&junk, sizeof(unsigned char), 1 , file1);
    junk = 1 - ((1 >> 8) << 8);
    fwrite(&junk, sizeof(unsigned char), 1 , file1);
    junk = 0;
    fwrite(&junk, sizeof(unsigned char), 1 , file1);

    for (i = 0; i < 2; i++) {
        junk = (info[0]) >> (8 * i);
        fwrite(&junk, sizeof(unsigned char), 1 , file1);
    }
    for (i = 0; i < 4; i++) {
        junk = (info[1]) >> (8 * i);
        fwrite(&junk, sizeof(unsigned char), 1 , file1);
    }
    for (i = 0; i < 4; i++) {
        junk = (info[1] * info[0] * (info[3] / 8)) >> (8 * i);
        fwrite(&junk, sizeof(unsigned char), 1 , file1);
    }
    for (i = 0; i < 2; i++) {
        junk = (info[2]) >> (8 * i);
        fwrite(&junk, sizeof(unsigned char), 1 , file1);
    }
    for (i = 0; i < 2; i++) {
        junk = (info[3]) >> (8 * i);
        fwrite(&junk, sizeof(unsigned char), 1 , file1);
    }
    strcpy(itemTag , "data");
    fwrite(itemTag , sizeof(unsigned char) , 4 , file1);
    for (i = 0; i < 4; i++) {
        junk = (info[4] * info[0] * (info[3] / 8)) >> (8 * i);
        fwrite(&junk, sizeof(unsigned char), 1 , file1);
    }

    return file1;
}

