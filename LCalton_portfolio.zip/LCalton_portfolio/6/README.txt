

This manuscript is the rough draft of a research article that myself and Dr. Zhangping Wei have submitted for publishing to the Applied Soft Computing Journal (https://www.sciencedirect.com/journal/applied-soft-computing) as of 10/2021.

© Copyright Landon Calton and Zhangping Wei.
